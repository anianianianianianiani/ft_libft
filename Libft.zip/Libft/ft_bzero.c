/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_bzero.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ababkeny <ababkeny@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/03/15 16:28:02 by ababkeny          #+#    #+#             */
/*   Updated: 2022/03/24 21:28:05 by ababkeny         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

void	ft_bzero(void *str, size_t len)
{
	ft_memset(str, 0, len);
}

// int	main (void)
// {
// 	char	dest[] = "oldstring";

// 	ft_bzero(dest, 3);

// 	printf("After memmove dest = %s", dest);
// 	return (0);
// }
