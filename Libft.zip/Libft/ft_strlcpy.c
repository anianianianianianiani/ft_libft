/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strlcpy.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ababkeny <ababkeny@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/03/19 14:46:06 by ababkeny          #+#    #+#             */
/*   Updated: 2022/03/28 18:04:16 by ababkeny         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>

size_t	ft_strlcpy(char *dst, const char *src, size_t size)
{
	size_t	i;

	i = 0;
	if (size != 0)
	{
		while (src[i] && i < (size - 1))
		{
			dst[i] = src[i];
			i++;
		}
		dst[i] = '\0';
	}
	while (src[i])
	i++;
	return (i);
}

// int	main(void)
// {
// 	char	dest[] = "hello";
// 	char	src[] = "world";

// 	printf("Before - dest = %s, src = %s\n", dest, src);
// 	ft_strlcpy(dest, src, 2);
// 	printf("After -  dest = %s, src = %s\n", dest, src);
// 	return (0);
// }
