/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_substr.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ababkeny <ababkeny@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/03/24 16:17:47 by ababkeny          #+#    #+#             */
/*   Updated: 2022/03/31 19:16:04 by ababkeny         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

char	*ft_substr(char const *s, unsigned int start, size_t len)
{
	char	*str;
	size_t	i;
	size_t	size;

	if (s == NULL)
		return (NULL);
	size = ft_strlen((char *)s);
	str = (char *)malloc((len + 1));
	i = 0;
	if (str == NULL )
		return (NULL);
	while (i < len && (unsigned int)ft_strlen((char *)s) > start)
	{
		str[i] = s[start];
		start++;
		i++;
	}
	str[i] = '\0';
	return (str);
}
// int main()
// {
// 	char s1[] = "Ani";
// 	unsigned int	start = 3;
// 	size_t len = 10;

// 	printf("%s", ft_substr(s1,start, len));
// 	return (0);
// }
