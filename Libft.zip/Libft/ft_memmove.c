/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_memmove.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ababkeny <ababkeny@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/03/19 20:41:37 by ababkeny          #+#    #+#             */
/*   Updated: 2022/03/28 18:15:18 by ababkeny         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

void	*ft_memmove(void *dst, const void *src, size_t len)
{
	size_t	i;

	i = 0;
	if (dst == NULL && src == NULL)
		return (NULL);
	if (dst >= src)
	{
		i = len - 1;
		while (len > 0)
		{
			*(char *)(dst + i) = *(const char *)(src + i);
			i--;
			len--;
		}
		return (dst);
	}
	while (len > 0)
	{
		*(char *)(dst + i) = *(const char *)(src + i);
		i++;
		len--;
	}
	return (dst);
}

// int	main()
// 	{
// 	char	str[] = "START";
// 	char	str2[] = "stoa";
// 	ft_memmove(str, str2, 2);
// 	printf("%s\n", str);
// 	return (0);
// 	}
