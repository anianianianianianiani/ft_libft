/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strlcat.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ababkeny <ababkeny@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/03/19 17:27:17 by ababkeny          #+#    #+#             */
/*   Updated: 2022/03/28 22:38:07 by ababkeny         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

size_t	ft_strlcat(char *dst, const char *src, size_t size)
{
	size_t	altdst;
	size_t	lsrc;
	size_t	i;

	if (size == 0)
		return (ft_strlen((char *)src));
	lsrc = ft_strlen((char *)src);
	i = 0;
	while (dst[i] && i < size)
	i++;
	altdst = i;
	while (src[i - altdst] && i < size - 1)
	{
	dst[i] = src[i - altdst];
	i++;
	}
	if (altdst < size)
		dst[i] = '\0';
	return (altdst + lsrc);
}

// int	main(void)
// {
// 	char	*s1;
// 	char	*s2;
// 	char 	*dest;

// 	dest = (char *)malloc(sizeof(*dest) * 15);
// 	memset(dest, 0, 15);
// 	memset(dest, 'r', 6);
// 	dest[10] = 'a';

// 	printf("%zu",ft_strlcat(dest, "lorem ipsum dolor sit amet", 0));
// 	write(1, "\n", 1);
// 	write(1, dest, 15);
// 	write(1, "\n", 1);
// 	return (0);
// }
