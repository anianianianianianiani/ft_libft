/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strdup.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ababkeny <ababkeny@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/03/23 17:45:26 by ababkeny          #+#    #+#             */
/*   Updated: 2022/03/28 19:54:10 by ababkeny         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

char	*ft_strdup(const char *str)
{
	char	*duplicate;
	int		i;

	i = 0;
	while (str[i])
	i++;
	duplicate = (char *)malloc(sizeof(char) * (i + 1));
	if (!duplicate)
		return (NULL);
	i = 0;
	while (str[i])
	{
	duplicate[i] = str[i];
	i++;
	}
	duplicate[i] = '\0';
	return (duplicate);
}

// int	main(void)
// 	{
// 	char	*string;
// 	char	*duplicate;

// 	string = "Love";
// 	duplicate = ft_strdup (string);
// 	printf ("Duplicate is: %s\n", duplicate);
// 	free (duplicate);
// 	return (0);
// }
