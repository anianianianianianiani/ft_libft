/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strrchr.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ababkeny <ababkeny@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/03/20 20:30:00 by ababkeny          #+#    #+#             */
/*   Updated: 2022/03/28 20:19:38 by ababkeny         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

char	*ft_strrchr(const char *str, int c)
{
	char	*find;

	find = NULL;
	while (*str)
	{
		if (*str == (char )c)
			find = (char *)str;
		str++;
	}
	if (*str == (char)c)
		return ((char *)str);
	return (find);
}

// int	main(void)
// {
// 	char	s[]="hello.barevba.rev";
// 	char	k = '.';

// 	printf("%s", ft_strrchr (s , k));
// 	return (0);
// }
