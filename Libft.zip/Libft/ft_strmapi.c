/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strmapi.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ababkeny <ababkeny@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/04/01 12:14:59 by ababkeny          #+#    #+#             */
/*   Updated: 2022/04/01 14:11:37 by ababkeny         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

// char	ft_putstr(unsigned int i, char s)
// {
// 	if (i % 2 == 0)
// 		return (s - 32);
// 	else
// 		return (s);

// }

char	*ft_strmapi(char const	*s, char (*f)(unsigned int, char))
{
	unsigned int	i;
	char			*str;

	if (!s)
		return (NULL);
	i = 0;
	str = (char *)malloc(sizeof(char) * (ft_strlen((char *)s) + 1));
	if (str == NULL)
		return (NULL);
	while (s[i])
	{
		str[i] = f(i, s[i]);
		i++;
	}
	str[i] = '\0';
	return (str);
}

// int	main(void)
// {
// 	char		*ss;

// 	ss = "/////aaa////";
// 	printf("%s\n", ft_strmapi(ss, &ft_putstr));
// 	return (0);
// }
