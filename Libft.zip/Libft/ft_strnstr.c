/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strnstr.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ababkeny <ababkeny@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/03/23 15:34:41 by ababkeny          #+#    #+#             */
/*   Updated: 2022/03/28 21:39:46 by ababkeny         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

char	*ft_strnstr(const char *haystack, const char *needle, size_t len)
{
	size_t	strlen;

	if (*needle == '\0' || needle == NULL)
		return ((char *)haystack);
	if (*haystack == '\0' || haystack == NULL)
		return (NULL);
	strlen = ft_strlen((char *)needle);
	while (*haystack != '\0' && len)
	{
		if (strlen > len)
			return (NULL);
		if (!ft_strncmp((char *)haystack, (char *)needle, strlen))
			return ((char *)haystack);
		haystack++;
		len--;
	}
	return (NULL);
}

// int	main(void)
// {
// 	const char	*haystack;
// 	const char	*needle;
// 	char		*result;

// 	haystack = "lorem ipsum dolor sit amet";
// 	needle = "ipsum";
// 	result = ft_strnstr(haystack, needle, 15);
// 	printf("The substring is: %s\n", result);
// 	return (0);
// }
