/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_split.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ababkeny <ababkeny@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/03/30 19:53:23 by ababkeny          #+#    #+#             */
/*   Updated: 2022/04/02 13:31:50 by ababkeny         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

int	free_malloc(char **str) //this function can also be void, but it is int and returns true - for using it in if operatr in the ft_split function
{
	int	i;

	i = 0;
	if (str[i])
		free(str[i++]);
	if (str)
		free(str);
		i++;
	return (1);
}

static size_t	word_length(char const *s, char c)
{
	size_t	i;
	size_t	count;

	i = 0;
	count = 0;
	while (s[i])
	{
		while (s[i] == c)
			i++;
		while (s[i] != c && s[i] != '\0')
		{
			count++;
			i++;
		}
	}
	return (count);
}

static char	**fill_str(char **store, char const *str, char c)
{
	size_t		len;
	size_t		index;
	char const	*st;

	index = 0;
	while (*str)
	{
		if (*str != c)
		{
			len = 0;
			while (*str && *str != c)
			{
				len++;
				str++;
			}
			st = str - len;
			store[index] = ft_substr(st, 0, len);
			if (store[index++] == NULL)
				return (NULL);
		}
		else
			str++;
	}
	store[index] = 0;
	return (store);
}

char	**ft_split(char const *s, char c)
{
	char	**splited_string;
	size_t	word_len;

	if (!s)
		return (NULL);
	word_len = word_length(s, c);
	splited_string = malloc(sizeof(char *) * (word_len + 1));
	if (!splited_string)
		return (NULL);
	splited_string = fill_str(splited_string, s, c);
	if (!splited_string && free_malloc(splited_string)) /*first operator will read if !splited_string is true and it will do free_malloc, but if !splited_string is not true it will not free and will not return NULL*/
		return (NULL);
	return (splited_string);
}

// int	main(void)
// {
// 	char const	*s;
// 	char		**ret;

// 	s = "Love is wherever I am with you";
// 	ret = ft_split(s, ' ');
// 	printf ("Splited string 1 %s\n", ret[0]);
// 	printf ("Splited string 2 %s\n", ret[1]);
// 	printf ("Splited string 3 %s\n", ret[2]);
// 	printf ("Splited string 4 %s\n", ret[3]);
// 	printf ("Splited string 5 %s\n", ret[4]);
// 	printf ("Splited string 6 %s\n", ret[5]);
// 	printf ("Splited string 7 %s\n", ret[6]);
// }
