/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_memchr.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ababkeny <ababkeny@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/03/21 15:41:41 by ababkeny          #+#    #+#             */
/*   Updated: 2022/03/25 20:21:33 by ababkeny         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

void	*ft_memchr(const void *s, int c, size_t n)
{
	size_t	i;
	char	*string;

	string = (char *)s;
	i = 0;
	while (i < n)
	{
		if (string[i] == c)
			return ((string + i));
		i++;
	}
	return (0);
}

// int	main(void)
// {
// 	const char	str[] = "loveiswherever.Iamwithyou";
// 	const char	ch = '.';
// 	char		*ret;

// 	ret = ft_memchr(str, ch, strlen(str));

// 	printf("String after |%c is - %s\n", ch, ret);

// 	return (0);
// }
