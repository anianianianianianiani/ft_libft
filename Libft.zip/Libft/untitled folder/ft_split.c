#include "libft.h"

int	ft_sizetab(char const *s1, char c)
{
	int	i;
	int	len;

	len = 0;
	i = 0;
	while (s1[i])
	{
		while (s1[i] == c)
			i++;
		while (s1[i] != c && s1[i])
			i++;
		len++;
	}
	if (len == 0 || s1[i - 1] != c)
		len++;
	return (len);
}

char	**spl(char const *s, char c, char **split)
{
	int		i;
	int		j;
	int		k;

	i = 0;
	j = 0;
	k = -1;
	while (s[++k])
	{
		if (s[k] != c && s[k])
			i++;
		if (s[k] == c && i > 0)
		{
			split[j++] = ft_substr(s, k - i, i);
			i = 0;
		}
	}
	if (i != 0)
		split[j++] = ft_substr(s, k - i, i);
	split[j] = 0;
	return (split);
}

char	**ft_split(char const *s, char c)
{
	char	**split;

	split = malloc(8 * ft_sizetab(s, c));
	if (!split)
		return (0);
	split = spl(s, c, split);
	return (split);
}
