/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strchr.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ababkeny <ababkeny@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/03/20 17:50:53 by ababkeny          #+#    #+#             */
/*   Updated: 2022/03/23 15:08:34 by ababkeny         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

//The strchr() function locates the first occurrence of c (converted to a
//char) in the string pointed to by s.  The terminating null character is
//considered to be part of the string; therefore if c is `\0', the func-
//tions locate the terminating `\0'
//Return Values
//return a pointer to the located
//character, or NULL if the character does not appear in the string.
#include <stdio.h>

char	*ft_strchr(const char *str, int c)
{
	while (*str != '\0' && c != *str)
	{
	str++;
	}
	if (*str == c)
		return ((char *)str);
	return (0);
}

// int main()
// {
//   char str[] = "iloveyoubabe.anditisquitealright";
//   char ch = '.';
//   char *ret;

//   ret = ft_strchr(str, ch);
//   printf ("String after %c is - %s\n", ch, ret);
//   return (0);
// }

// int	main(void)
// {
//     char    s[]="hello.barev.barev";
//     char    k = '.';

//     printf("%s", ft_strchr(s,k));
//     return (0);
// }
