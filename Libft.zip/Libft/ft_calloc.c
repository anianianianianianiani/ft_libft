/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_calloc.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ababkeny <ababkeny@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/03/23 16:59:57 by ababkeny          #+#    #+#             */
/*   Updated: 2022/03/24 21:30:16 by ababkeny         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

void	*ft_calloc(size_t count, size_t size)
{
	void	*ptr;

	ptr = malloc(count * size);
	if (ptr == NULL)
		return (ptr);
	ft_bzero(ptr, size * count);
	return (ptr);
}

// int	main(void)
// {
// 	char str [] = "11";
// 	char *str1;

// 	str1 = ft_calloc (sizeof(str), 1);
// 	printf ("Calloc is: %s\n", str1);
// 	free (str1);
// 	return (0);
// }
