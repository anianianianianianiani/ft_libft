/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_memset.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ababkeny <ababkeny@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/03/15 15:57:27 by ababkeny          #+#    #+#             */
/*   Updated: 2022/03/20 16:48:33 by ababkeny         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

void	*ft_memset(void *str, int c, size_t len)
{
	unsigned char	*s;

	s = (unsigned char *)str;
	while (len > 0)
	{
		*s = c;
		s++;
		len--;
	}
	return (str);
}

// int main () {
//    char dest[] = "oldstring";

//    ft_memset(dest, '+', 3);
//    printf("After memmove dest = %s", dest);

//    return(0);
// }
