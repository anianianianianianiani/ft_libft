/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strlcpy.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: anbabken <anbabken@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/01/30 11:49:33 by anbabken          #+#    #+#             */
/*   Updated: 2023/01/30 11:49:45 by anbabken         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

size_t	ft_strlcpy(char *dst, const char *src, size_t size)
{
	size_t	i;

	i = 0;
	if (size != 0)
	{
		while (src[i] && i < (size - 1))
		{
			dst[i] = src[i];
			i++;
		}
		dst[i] = '\0';
	}
	while (src[i])
	i++;
	return (i);
}

// int main(void)
// {
// 	char dst[] = "hello";
// 	char src[] = "world";
// 	printf("%s = naxkinum, src = %s\n",dst, src );
// 	ft_strlcpy(dst, src, 2);
// 	printf("%s = heto, src = %s\n",dst, src );
//     char d[] = "hello";
// 	char s[] = "world";
// 	printf("%s = naxkinum, src = %s\n",d, s );
// 	strlcpy(d, s, 2);
// 	printf("%s = heto, src = %s\n",d, s );
// 	return(0);
// }