/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strchr.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: anbabken <anbabken@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/01/18 16:45:32 by anbabken          #+#    #+#             */
/*   Updated: 2023/01/30 13:02:34 by anbabken         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"
#include <stdio.h>

char	*ft_strchr(const char *s, int c)
{
	while (*s && (char)c != *s)
		s++;
	if (*s == (char)c)
		return ((char *)s);
	return (NULL);
}
/*int main()
{
    char str[] = "gites.kaghamby.mirg.che";
    char ch = '.';
    char *kagh;
    kagh = ft_strchr(str, ch);
    printf("string after %c is %s\n", ch, kagh);
}*/