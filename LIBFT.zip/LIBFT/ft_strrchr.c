/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strrchr.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: anbabken <anbabken@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/01/19 11:45:46 by anbabken          #+#    #+#             */
/*   Updated: 2023/02/20 18:41:37 by anbabken         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"
#include <stdio.h>

char	*ft_strrchr(const char *str, int c)
{
	char	*find;

	find = NULL;
	while (*str)
	{
		if (*str == (char )c)
			find = (char *)str;
		str++;
	}
	if (*str == (char)c) 
		return ((char *)str);
	return (find);
}
/*int main()
{
    char str[] = "gites.kaghamby.mirg.che";
    char ch = '.';
    char *kagh;
    kagh = ft_strrchr(str, ch);
    printf("string after %c is %s\n", ch, kagh);
}*/