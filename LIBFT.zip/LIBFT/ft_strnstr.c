/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strnstr.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: anbabken <anbabken@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/01/28 15:24:16 by anbabken          #+#    #+#             */
/*   Updated: 2023/02/02 18:30:55 by anbabken         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"
#include <stdio.h>

char	*ft_strnstr(const char *haystack, const char *needle, size_t len)
{
	size_t	str_len;
	size_t	cmp;

	if (!haystack && len == 0)
		return (0);
	if (*needle == '\0' || needle == NULL)
		return ((char *)haystack);
	if (*haystack == '\0' || haystack == NULL)
		return (NULL);
	str_len = ft_strlen((char *)needle);
	while (len > 0)
	{
		if (!haystack || str_len > len)
			return (NULL);
		cmp = ft_strncmp((char *)haystack, (char *)needle, str_len);
		if (!cmp)
			return ((char *)haystack);
		haystack++;
		len--;
	}
	return (NULL);
}

// int	main(void)
// {
// 	const char *largestring = "alo vay exav";
// 	const char *smallstring = "vay";
// 	char *ptr;
// 	ptr = strnstr(largestring, smallstring, 0);
// 	printf("%s",  ptr);
// }