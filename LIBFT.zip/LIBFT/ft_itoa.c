/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_itoa.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: anbabken <anbabken@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/01/21 16:18:59 by anbabken          #+#    #+#             */
/*   Updated: 2023/01/31 14:02:11 by anbabken         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

int	ft_int_min(int num, char *s)
{
	if (num == -2147483648)
	{
		num = -147483648;
		s[1] = '2';
	}
	return (num);
}

int	ft_len(int n)
{
	int	len;

	len = 0;
	if (n < 0)
		len++;
	if (n == 0)
		return (len + 1);
	while (n != 0)
	{
		n /= 10;
		len++;
	}
	return (len);
}

char	*ft_itoa(int nb)
{
	long int	n;
	char		*str;
	int			len;

	n = nb;
	len = ft_len(n);
	str = (char *)malloc (sizeof(char) * (len + 1));
	if (!(str))
		return (NULL);
	if (n == 0)
		str[0] = '0';
	if (n < 0)
	{
		n = ft_int_min(n, str);
		str[0] = '-';
		n *= -1;
	}
	str[len] = '\0';
	while (n > 0)
	{
		str[len - 1] = 48 + (n % 10);
		n /= 10;
		len--;
	}
	return (str);
}

// int main()
// {
// 	printf("%s", ft_itoa(-2147483648ll));
// 	return 0;
// }