/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strtrim.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: anbabken <anbabken@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/01/28 15:40:54 by anbabken          #+#    #+#             */
/*   Updated: 2023/02/02 18:30:12 by anbabken         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

char	*ft_strtrim(char const *s1, char const *set)
{
	size_t	i;
	size_t	start;
	size_t	end;
	char	*str;

	str = 0;
	if (s1 && set)
	{
		i = 0;
		start = 0;
		end = ft_strlen((char *)s1);
		while (ft_strchr(set, s1[start]) && start < end)
			start++;
		while (ft_strchr(set, s1[end - 1]) && end > start)
			end--;
		str = (char *)malloc(sizeof(char) * (end - start + 1));
		if (!str)
			return (0);
		while (start < end)
			str[i++] = s1[start++];
		str[i] = '\0';
	}
	return (str);
}

// int main()
// {
// 	char a[] = "ananankaghambnanaanai";
// 	char s[] = "an";
// 	printf("%s", ft_strtrim(a, s));
// }