/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strlcat.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: anbabken <anbabken@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/01/23 20:12:21 by anbabken          #+#    #+#             */
/*   Updated: 2023/01/23 21:01:29 by anbabken         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

size_t	ft_strlcat(char *dst, const char *src, size_t dstsize)
{
	size_t	ldst;
	size_t	lsrc;
	size_t	i;

	if (dstsize == 0)
		return (ft_strlen((char *)src));
	lsrc = ft_strlen((char *)src);
	i = 0;
	while (dst[i] && i < dstsize)
		i++;
	ldst = i;
	while (src[i - ldst] && i < dstsize - 1)
	{
		dst[i] = src[i - ldst];
		i++;
	}
	if (ldst < dstsize)
		dst[i] = '\0';
	return (ldst + lsrc);
}

// int main(void)
// {
// 	char dst[] = "hello";
// 	char src[] = "world";	
// 	printf("%zu\n", ft_strlcat(dst, src, 2) );
// 	return(0);
// }